using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BingoCell : MonoBehaviour
{
    int m_cellNumber = 0;

    [SerializeField]
    Text m_numText = null;

    public void NumberChange(int cellNum)
    {
        m_cellNumber = cellNum;
        m_numText.text = m_cellNumber.ToString();
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }
}
