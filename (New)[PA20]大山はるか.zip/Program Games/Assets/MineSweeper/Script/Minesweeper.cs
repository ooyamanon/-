﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Minesweeper : MonoBehaviour
{
    [SerializeField]
    private int _rows = 1;// 縦

    [SerializeField]
    private int _columns = 1;// 横

    [SerializeField]
    private int _mineCount = 1;// 爆弾の数

    [SerializeField]
    private Cell _cellPrefab = null;

    [SerializeField]
    private GridLayoutGroup _gridLayoutGroup = null;

    [SerializeField]
    GameObject _gameOverPanel = null;

    [SerializeField]
    Text _gameOverText = null;

    Cell[,] cellsList = null;

    private void OnValidate()
    {
        if (_columns < _rows)
        {
            _gridLayoutGroup.constraint = GridLayoutGroup.Constraint.FixedColumnCount;
            _gridLayoutGroup.constraintCount = _columns;
        }
        else
        {
            _gridLayoutGroup.constraint = GridLayoutGroup.Constraint.FixedRowCount;
            _gridLayoutGroup.constraintCount = _rows;
        }
    }

    private void Start()
    {
        cellsList = new Cell[_rows, _columns];// Cellを入れる配列
        var parent = _gridLayoutGroup.gameObject.transform;
        for (int r = 0; r < _rows; r++)
        {
            for (int c = 0; c < _columns; c++)
            {
                var cell = Instantiate(_cellPrefab);
                cell.transform.SetParent(parent);
                cell.CellState = CellState.None;
                cellsList[r, c] = cell;
                cell.CellPosition(r, c);


                //var cellCover = Instantiate(_cellCoverPrefab);
                //cellCover.transform.SetParent(hParent);
                //var button = cellCover.GetComponent<Button>();
                //var ce = new Button.ButtonClickedEvent();
                //ce.AddListener(ClickCellCover);
                //button.onClick = ce;
                //coversList[r, c] = cellCover;
            }
        }

        for (int i = 0; i < _mineCount;)// 爆弾を入れる処理
        {
            if (_mineCount > _rows * _columns)
            {
                Debug.Log("mine over!!");
                break;
            }
            var r = Random.Range(0, _rows);
            var c = Random.Range(0, _columns);
            var cell = cellsList[r, c];
            if (cell.CellState == CellState.None)// Cellに何も入っていない時のみ爆弾を入れる
            {
                cell.CellState = CellState.Mine;
                i++;
                //AddMineCount(r, c)
            }
        }

        for (int r = 0; r < _rows; r++)
        {

            for (int c = 0; c < _columns; c++)
            {
                var cell = cellsList[r, c];
                if (cell.CellState == CellState.Mine) { continue; }//選択したセル自体がMineだったらやり直し
                int count = 0;// 周りの爆弾の数
                if (r >= 1 && c >= 1 && cellsList[r - 1, c - 1].CellState == CellState.Mine)// 左上
                {
                    count++;
                }
                if (r >= 1 && cellsList[r - 1, c].CellState == CellState.Mine)// 上
                {
                    count++;
                }
                if (r >= 1 && c < _columns - 1 && cellsList[r - 1, c + 1].CellState == CellState.Mine)// 右上
                {
                    count++;
                }
                if (c >= 1 && cellsList[r, c - 1].CellState == CellState.Mine)// 左
                {
                    count++;
                }
                if (c < _columns - 1 && cellsList[r, c + 1].CellState == CellState.Mine)// 右
                {
                    count++;
                }
                if (r < _rows - 1 && c >= 1 && cellsList[r + 1, c - 1].CellState == CellState.Mine)// 左下
                {
                    count++;
                }
                if (r < _rows - 1 && cellsList[r + 1, c].CellState == CellState.Mine)// 下
                {
                    count++;
                }
                if (r < _rows - 1 && c < _columns - 1 && cellsList[r + 1, c + 1].CellState == CellState.Mine)// 右下
                {
                    count++;
                }
                cell.CellState = (CellState)count;
                Debug.Log(r + " " + c);
            }
        }
    }

    /*private void AddMineCount(int r, int c) //爆弾の入ったセルを中心に数を加算していく方法
    {
        int count = 0;
          var left = c - 1;
          var right = c + 1;
          var top = r - 1;
          var bottom = r + 1;
          if (top >= 0)
          {
              if (left >= 0 && cellsList[top, left].CellState != CellState.Mine) { cellsList[top, left].CellState++; }
              if (cellsList[top, c].CellState != CellState.Mine) { cellsList[top, c].CellState++; }
              if (right < _columns && cellsList[top, right].CellState != CellState.Mine) { cellsList[top, right].CellState++; }
          }
          if (left >= 0 && cellsList[r, left].CellState != CellState.Mine) { cellsList[r, left].CellState++; }
          if (right < _columns && cellsList[r, right].CellState != CellState.Mine) { cellsList[r, right].CellState++; }
          if (bottom < _rows)
          {
              if (left >= 0 && cellsList[bottom, left].CellState != CellState.Mine) { cellsList[bottom, left].CellState++; }
              if (cellsList[bottom, c].CellState != CellState.Mine) { cellsList[bottom, c].CellState++; }
              if (right < _columns && cellsList[bottom, right].CellState != CellState.Mine) { cellsList[bottom, right].CellState++; }
          }
         
    }*/

    public void GameOver()
    {
        _gameOverPanel.gameObject.SetActive(true);
    }

    public void Clear()
    {
        _gameOverPanel.gameObject.SetActive(true);
        _gameOverPanel.GetComponent<Image>().color = Color.green;
        _gameOverText.text = "成功！";
    }

    public void CellOpen()
    {
        int cellOpenCount = 0;
        foreach (var item in cellsList)
        {
            if (!item.coverOpen)
            {
                cellOpenCount++;
                Debug.Log(cellOpenCount);
            }
            if (cellOpenCount == cellsList.Length - _mineCount)
            {
                Clear();
            }
        }
    }

    public void CellFind(int row, int col)
    {
        var left = col - 1;
        var right = col + 1;
        var top = row - 1;
        var bottom = row + 1;
        if (top >= 0)
        {
            if (left >= 0 && cellsList[top, left].CellState == CellState.None && cellsList[top, left].coverOpen)//左上
            {
                cellsList[top, left].CellReStart();
            }
            if (cellsList[top, col].CellState == CellState.None && cellsList[top, col].coverOpen)//上
            {
                cellsList[top, col].CellReStart();
            }
            if (right < _columns && cellsList[top, right].CellState == CellState.None && cellsList[top, right].coverOpen)//右上
            {
                cellsList[top, right].CellReStart();
            }
        }
        if (left >= 0 && cellsList[row, left].CellState == CellState.None && cellsList[row, left].coverOpen)//左
        {
            cellsList[row, left].CellReStart();
        }
        if (right < _columns && cellsList[row, right].CellState == CellState.None && cellsList[row, right].coverOpen)//右
        {
            cellsList[row, right].CellReStart();
        }
        if (bottom < _rows)
        {
            if (left >= 0 && cellsList[bottom, left].CellState == CellState.None && cellsList[bottom, left].coverOpen)//左下
            {
                cellsList[bottom, left].CellReStart();
            }
            if (cellsList[bottom, col].CellState == CellState.None && cellsList[bottom, col].coverOpen)//下
            {
                cellsList[bottom, col].CellReStart();
            }
            if (right < _columns && cellsList[bottom, right].CellState == CellState.None && cellsList[bottom, right].coverOpen)//右下
            {
                cellsList[bottom, right].CellReStart();
            }
        }
        if (cellsList[row, col].CellState == CellState.None)
        {
            for (int i = -1; i < 2; i++)
            {
                for (int k = -1; k < 2; k++)
                {
                    if (row + k == -1 || row + k == cellsList.GetLength(0) || col + i == -1 || col + i == cellsList.GetLength(1))
                    {
                        continue;
                    }
                    else if (i == 0 && k == 0)
                    {
                        continue;
                    }
                    else
                    {
                        cellsList[row + k, col + i].CoverDelete();
                    }
                }
            }
        }

    }

    public void NoneCellOpen(int row, int col)
    {
        var left = col - 1;
        var right = col + 1;
        var top = row - 1;
        var bottom = row + 1;
        if (top >= 0)
        {
            if (left >= 0 && cellsList[top, left].CellState == CellState.None && cellsList[top, left].coverOpen)//左上
            {
                cellsList[top, left].CellReStart();
            }
            else if (left >= 0 && cellsList[top, left].CellState != CellState.None && cellsList[top, left].coverOpen)//左上のカバー消し
            {
                cellsList[top, left].CoverDelete();
            }
            if (cellsList[top, col].CellState == CellState.None && cellsList[top, col].coverOpen)//上
            {
                cellsList[top, col].CellReStart();
            }
            else if (cellsList[top, col].CellState != CellState.None && cellsList[top, col].coverOpen)//上のカバー消し
            {
                cellsList[top, col].CoverDelete();
            }
            if (right < _columns && cellsList[top, right].CellState == CellState.None && cellsList[top, right].coverOpen)//右上
            {
                cellsList[top, right].CellReStart();
            }
            else if (right < _columns && cellsList[top, right].CellState != CellState.None && cellsList[top, right].coverOpen)//右上のカバー消し
            {
                cellsList[top, right].CoverDelete();
            }
        }
        if (left >= 0 && cellsList[row, left].CellState == CellState.None && cellsList[row, left].coverOpen)//左
        {
            cellsList[row, left].CellReStart();
        }
        else if (left >= 0 && cellsList[row, left].CellState != CellState.None && cellsList[row, left].coverOpen)//左のカバー消し
        {
            cellsList[row, left].CoverDelete();
        }
        if (right < _columns && cellsList[row, right].CellState == CellState.None && cellsList[row, right].coverOpen)//右
        {
            cellsList[row, right].CellReStart();
        }
        else if (right < _columns && cellsList[row, right].CellState != CellState.None && cellsList[row, right].coverOpen)//右のカバー消し
        {
            cellsList[row, right].CoverDelete();
        }
        if (bottom < _rows)
        {
            if (left >= 0 && cellsList[bottom, left].CellState == CellState.None && cellsList[bottom, left].coverOpen)//左下
            {
                cellsList[bottom, left].CellReStart();
            }
            else if (left >= 0 && cellsList[bottom, left].CellState != CellState.None && cellsList[bottom, left].coverOpen)//左下のカバー消し
            {
                cellsList[bottom, left].CoverDelete();
            }
            if (cellsList[bottom, col].CellState == CellState.None && cellsList[bottom, col].coverOpen)//下
            {
                cellsList[bottom, col].CellReStart();
            }
            else if (cellsList[bottom, col].CellState != CellState.None && cellsList[bottom, col].coverOpen)//下のカバー消し
            {
                cellsList[bottom, col].CoverDelete();
            }
            if (right < _columns && cellsList[bottom, right].CellState == CellState.None && cellsList[bottom, right].coverOpen)//右下
            {
                cellsList[bottom, right].CellReStart();
            }
            else if (right < _columns && cellsList[bottom, right].CellState != CellState.None && cellsList[bottom, right].coverOpen)//右下のカバー消し
            {
                cellsList[bottom, right].CoverDelete();
            }
        }
    }
}
