﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public enum CellState
{
    None = 0,
    One = 1,
    Two = 2,
    Three = 3,
    Four = 4,
    Five = 5,
    Six = 6,
    Seven = 7,
    Eight = 8,

    Mine = -1,
}

public class Cell : MonoBehaviour
{
    [SerializeField]
    GameObject cellCover = null;

    [SerializeField]
    private Text _view = null;

    public bool coverOpen = true;

    int _cellRow = 0;
    int _cellCol = 0;

    GameObject mineSweeper = null;

    [SerializeField]
    private CellState _cellState = CellState.None;
    public CellState CellState
    {
        get => _cellState;
        set
        {
            _cellState = value;
            OnCellStateChanged();
        }
    }

    private void OnValidate()
    {
        OnCellStateChanged();
    }

    public void Start()
    {
        mineSweeper = GameObject.Find("MinesweeperPanel");

        cellCover = transform.Find("CellCover").gameObject;
    }

    private void OnCellStateChanged()
    {
        if (_view == null)
        {
            return;
        }
        if (_cellState == CellState.None)
        {
            _view.text = "";
        }
        else if (_cellState == CellState.Mine)
        {
            _view.text = "X";
            _view.color = Color.red;
        }
        else
        {
            _view.text = ((int)_cellState).ToString();
            _view.color = Color.blue;
        }
    }

    public void FlagChange()
    {
        coverOpen = false;
        mineSweeper.GetComponent<Minesweeper>().CellFind(_cellRow, _cellCol);
    }

    public void CellPosition(int row, int col)
    {
        _cellRow = row;
        _cellCol = col;
    }

    public void CellReStart()
    {
        coverOpen = false;
        cellCover.gameObject.SetActive(false);
        mineSweeper.GetComponent<Minesweeper>().NoneCellOpen(_cellRow, _cellCol);
    }

    public void CoverDelete()
    {
        coverOpen = false;
        cellCover.gameObject.SetActive(false);
    }
}
