﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CellCover : MonoBehaviour
{
    [SerializeField] GameObject flag = null;
    [SerializeField] GameObject unknown = null;
    [SerializeField] Cell cell = null;
    GameObject bomb = null;

    public void Start()
    {
        bomb = GameObject.Find("MinesweeperPanel");
    }

    public void ClickCellCover()
    {
        Debug.Log("ClickCellCover");

        if (Input.GetMouseButton(0))
        {
            Debug.Log("左で押されたで");
            if (flag.activeSelf == true)
            {
                Debug.Log("旗立ってんぞ");
            }
            else
            {
                this.gameObject.SetActive(false);
                if (cell.CellState == CellState.Mine)
                {
                    Debug.Log("爆発したで");
                    bomb.GetComponent<Minesweeper>().GameOver();
                }                
                else
                {
                    cell.GetComponent<Cell>().FlagChange(); //coverOpen = false;
                    bomb.GetComponent<Minesweeper>().CellOpen();
                }
            }            
        }
        else if (Input.GetMouseButton(1))
        {
            Debug.Log("右で押されたで");

            if (flag.activeSelf == false && unknown.activeSelf == false)
            {
                Debug.Log("旗立ったで");
                flag.gameObject.SetActive(true);
            }
            else if (flag.activeSelf == true && unknown.activeSelf == false)
            {
                flag.gameObject.SetActive(false);
                unknown.gameObject.SetActive(true);
            }
            else if (unknown == true)
            {
                unknown.gameObject.SetActive(false);
            }

        }
    }
}
