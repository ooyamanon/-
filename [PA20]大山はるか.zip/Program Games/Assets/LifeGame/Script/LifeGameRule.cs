using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LifeGameRule : MonoBehaviour
{
    [SerializeField]
    public LifeGameCell _cellPlefab = null;

    public void AroundCellFind(int col, int row) 
    {
        int cellLiveCount = 0;// ���͂̃Z���̐����m�F

        var left = col - 1;
        var right = col + 1;
        var top = row - 1;
        var bottom = row + 1;

        if (_cellPlefab._cellLive == false && cellLiveCount == 3)// �a��
        {

        }
        if (_cellPlefab._cellLive == true && cellLiveCount == 2 || cellLiveCount == 3)// ����
        {

        }
        if (_cellPlefab._cellLive == true && cellLiveCount < 1 || _cellPlefab._cellLive == true && cellLiveCount > 4)// �ߑa���ߖ�
        {

        }
    }
}
