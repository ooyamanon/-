using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Bingo : MonoBehaviour
{
    [SerializeField]
    private BingoCell m_cellPrefab = null;

    BingoCell[,] cellsList = null;

    [SerializeField]
    private GridLayoutGroup m_gridLayoutGroup = null;

    [SerializeField]
    private int m_rows = 1;// �c

    [SerializeField]
    private int m_columns = 1;// ��

    // Start is called before the first frame update
    void Start()
    {
        cellsList = new BingoCell[m_rows, m_columns];// Cell������z��
        var parent = m_gridLayoutGroup.gameObject.transform;
        for (int r = 0; r < m_rows; r++)
        {
            for (int c = 0; c < m_columns; c++)
            {
                var bingoCell = Instantiate(m_cellPrefab);
                bingoCell.transform.SetParent(parent);
                cellsList[r, c] = bingoCell;
            }
        }

        for (int i = 0; i < m_rows; i++)
        {
            int[] numList = new int[5];
            numList[0] = Random.Range(1 + (i * 15), 16 + (i * 15));
            
            for (int k = 1; k < m_columns; k++)
            {
                bool flag = false;
                int num1 = Random.Range(1 + (i * 15), 16 + (i * 15));
                foreach (var item in numList)
                {
                    if (item == num1)
                    {
                        k--;
                        flag = false;
                        break;
                    }
                    else
                    {
                        flag = true;
                    }
                }
                if (flag == true)
                {
                    numList[k] = num1;
                }
            }
            for (int h = 0; h < numList.Length; h++)
            {
                cellsList[h, i].NumberChange(numList[h]);
            }
        }
    }

    
}
