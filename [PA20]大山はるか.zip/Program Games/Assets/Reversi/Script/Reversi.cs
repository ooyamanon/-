﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class Reversi : MonoBehaviour
{
    [SerializeField]
    private int _rows = 8;//行(縦)

    [SerializeField]
    private int _columns = 8;//列(横)

    [SerializeField]
    private ReversiField _reversiFieldPrefab = null;

    [SerializeField]
    private GridLayoutGroup _gridLayoutGroup = null;

    ReversiField[,] _reversiFieldsList = null;

    [SerializeField]
    public GameObject _reversiPanelWrite = null;

    [SerializeField]
    public GameObject _reversiPanelBlack = null;

    // Start is called before the first frame update
    void Start()
    {
        if (_rows > _columns)//_rowが大きかったら揃える
        {
            _rows = _columns;
        }
        else if (_columns > _rows)//_colが大きかったら揃える
        {
            _columns = _rows;
        }



        _reversiFieldsList = new ReversiField[_rows, _columns];
        var parent = _gridLayoutGroup.gameObject.transform;
        for (int r = 0; r < _rows; r++)
        {
            for (int c = 0; c < _columns; c++)
            {
                var reversiField = Instantiate(_reversiFieldPrefab);
                reversiField.transform.SetParent(parent);
                //reversiField.StoneState = StoneState.None;
                _reversiFieldsList[r, c] = reversiField;

            }
        }
    }

    // Update is called once per frame
    void Update()
    {

    }

    private void OnStoneTurnOver()
    {

    }
}
